## How to Run 

Experiment 1, 2, 3 are outlined in the `execute()` function - first choose which experiement to run and comment out the code for the other experiments. 

Then run the program and see a window pop up for the graphs using 

```
python {path_to_easom.py}
```

Question 3

For question 3 you need to install numpy. 

That can be installed by pip3 install numpy.

From there simply put the command python3 q3tabusearch.py in your terminal

You will then be prompted for what experiment you want to run. This coordinates to the assignment manual. 
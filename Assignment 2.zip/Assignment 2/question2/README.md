## How to Run 

Start by compiling and running the program 

```
javac conga.java
java conga.java 
```

Then run through the program step by step, entering "n" to move to the next 
step of the program

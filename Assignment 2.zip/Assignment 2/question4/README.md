## How to Run 

Compile the program with files 

    Travel.java
    SimulatedAnnealing.java
    main.java
    City.java

Run Main to see console output.

The file n39k6.vrp has been hardcoded to run.

First half of output is using SA to minimize for travel distance starting from depot and ending at the depot, the second portion is optimizing for travel time. Note that the demand section has been used to mark the service time of each city.